module Spree
  module Api
    class ConfigController < Spree::Api::BaseController
    end
  end
end