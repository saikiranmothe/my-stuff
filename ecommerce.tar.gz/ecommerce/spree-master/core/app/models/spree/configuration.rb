module Spree
  class Configuration < ActiveRecord::Base

  end
end
