module Spree
  def self.version
    "2.2.0.beta"
  end
end
