FactoryGirl.define do
  factory :promotion, class: Spree::Promotion do
    name 'Promo'
  end
end
