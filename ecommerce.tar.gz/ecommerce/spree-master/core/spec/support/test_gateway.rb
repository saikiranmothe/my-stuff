class Spree::Gateway::Test < Spree::Gateway
end
