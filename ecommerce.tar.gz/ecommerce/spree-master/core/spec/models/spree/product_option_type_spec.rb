require 'spec_helper'

describe Spree::ProductOptionType do

end
