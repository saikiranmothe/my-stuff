require 'spec_helper'

describe Spree::Image do

end
