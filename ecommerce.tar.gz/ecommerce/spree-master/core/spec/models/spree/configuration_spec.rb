require 'spec_helper'

describe Spree::Configuration do

end
