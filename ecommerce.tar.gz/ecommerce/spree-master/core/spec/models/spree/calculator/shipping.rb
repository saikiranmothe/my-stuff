require_dependency 'spree/calculator'

module Spree
  class Calculator::Shipping < Calculator
    def compute(content_items)
    end
  end
end
