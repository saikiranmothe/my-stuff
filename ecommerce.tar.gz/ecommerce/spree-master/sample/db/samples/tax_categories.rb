Spree::TaxCategory.create!(:name => "Clothing")
Spree::TaxCategory.create!(:name => "Food")
