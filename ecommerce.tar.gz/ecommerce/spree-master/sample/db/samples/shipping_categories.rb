Spree::ShippingCategory.create!(:name => "Default")
