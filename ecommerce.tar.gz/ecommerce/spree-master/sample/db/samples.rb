Spree::Sample.load_sample("payment_methods")
Spree::Sample.load_sample("shipping_categories")
